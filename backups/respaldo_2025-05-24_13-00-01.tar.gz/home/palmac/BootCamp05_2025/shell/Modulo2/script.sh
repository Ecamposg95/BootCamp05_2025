#!/bin/bash
echo "Buscando archivos .txt"
find . -name "*.txt"
